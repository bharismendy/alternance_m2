function  WWHToWWHelpDirectory()
{
  return "";
}
