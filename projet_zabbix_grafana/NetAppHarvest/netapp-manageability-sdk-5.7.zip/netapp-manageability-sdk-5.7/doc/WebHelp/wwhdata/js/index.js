function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("B",null,null,"002");
var B=A.fA("browse APIs");
var C=B.fA("C#",new Array("46"));
C=B.fA("PowerShell Core",new Array("46"));
C=B.fA("VB.NET",new Array("46"));
A=P.fA("C",null,null,"002");
B=A.fA("comments");
C=B.fA("how to send feedback about documentation",new Array("75"));
A=P.fA("D",null,null,"002");
B=A.fA("documentation");
C=B.fA("how to receive automatic notification of changes to",new Array("75"));
C=B.fA("how to send feedback about",new Array("75"));
B=A.fA("documentation in MSDN format");
C=B.fA("C#",new Array("46"));
C=B.fA("PowerShell Core",new Array("46"));
C=B.fA("VB.NET",new Array("46"));
A=P.fA("F",null,null,"002");
B=A.fA("feedback");
C=B.fA("how to send comments about documentation",new Array("75"));
A=P.fA("I",null,null,"002");
B=A.fA("information");
C=B.fA("how to send feedback about improving documentation",new Array("75"));
A=P.fA("O",null,null,"002");
B=A.fA("OpenSSL with FIPS");
C=B.fA("upgrading",new Array("27"));
A=P.fA("S",null,null,"002");
B=A.fA("suggestions");
C=B.fA("how to send feedback about documentation",new Array("75"));
A=P.fA("T",null,null,"002");
B=A.fA("Twitter");
C=B.fA("how to receive automatic notification of documentation changes",new Array("75"));
A=P.fA("U",null,null,"002");
B=A.fA("upgrading");
C=B.fA("OpenSSL with FIPS",new Array("27"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
