// Copyright (c) 2000-2014 Quadralay Corporation.  All rights reserved.
//
/*jslint newcap: true, sloppy: true, vars: true, white: true */
/*global WWHFrame */
/*global FileData_Pairs */

// Search complete
//
WWHFrame.WWHSearch.fCheckForPhraseMatch(FileData_Pairs);
