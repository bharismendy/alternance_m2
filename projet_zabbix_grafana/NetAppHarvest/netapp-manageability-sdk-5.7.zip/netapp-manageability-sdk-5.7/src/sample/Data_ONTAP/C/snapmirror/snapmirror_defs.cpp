extern "C"
{
  int __mb_cur_max;
  int __lc_codepage;
  int __lc_handle;
  unsigned short *_pctype;
  int errno;
}
